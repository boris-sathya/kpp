<?php if(false !== strpos(strtolower($_SERVER['HTTP_ACCEPT']),'application/xhtml+xml')) 
header('Content-Type: application/xhtml+xml;  charset=utf-8'); 
else 
 header('Content-Type: text/html;  charset=utf-8'); echo '<?xml version="1.0" encoding="UTF-8"?>'; ?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/main.dwt" codeOutsideHTMLIsLocked="false" -->
  <head>
   <meta http-equiv="Cache-Control" content="public"/>
   <meta content="K++ Search" name="Generator" />
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <!-- InstanceBeginEditable name="doctitle" -->
  <title>K++</title>
  <!-- InstanceEndEditable -->
  
  <!-- InstanceBeginEditable name="head" -->
<!--beginstyle--><link href="css/style.css" type="text/css" rel="stylesheet" /><!--endstyle-->
  <!-- InstanceEndEditable -->
  <!--design#23-->
  </head>
<body>
<div class="header"><!--beginlogo--><img src="images/logo_72.jpg" width="117" height="21" alt="image" /><!--endlogo--><!--beginlogotext--> <!--endlogotext-->
</div>
 
   <div class="BodyText">
	
<div class="homeng">
<!-- InstanceBeginEditable name="topdes" -->Search<!-- InstanceEndEditable --></div>

<div class="homeng">
<!-- InstanceBeginEditable name="botdes" --><form action="searchresults.php" method="get"><input type="text" name="inputbox" />
<input type="submit" value="Search" /></form>
<!-- InstanceEndEditable --></div>
<!--endcontent-->
<!--beginserver-->
<!--endserver-->
<!--beginbottomsearch--><!--endbottomsearch--></div>


<div class="footer">
<!--beginfooter-->mobile version by ICW<!--endfooter--></div><!--beginadfooter-->
   
</body></html>