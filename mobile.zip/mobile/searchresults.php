<?php if(false !== strpos(strtolower($_SERVER['HTTP_ACCEPT']),'application/xhtml+xml')) 
header('Content-Type: application/xhtml+xml;  charset=utf-8'); 
else 
 header('Content-Type: text/html;  charset=utf-8'); echo '<?xml version="1.0" encoding="UTF-8"?>'; ?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/main.dwt" codeOutsideHTMLIsLocked="false" -->
  <head>
   <meta http-equiv="Cache-Control" content="public"/>
   <meta content="K++ Search" name="Generator" />
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <!-- InstanceBeginEditable name="doctitle" -->
  <title>K++ Results</title>
  <!-- InstanceEndEditable -->
  
  <!-- InstanceBeginEditable name="head" -->
<!--beginstyle--><link href="css/style.css" type="text/css" rel="stylesheet" /><!--endstyle-->
  <!-- InstanceEndEditable -->
  <!--design#23-->
  </head>
  <body>
  <form method="get" action="searchresults.php">
		<input name="inputbox" type="text" />
		<input type="submit" value="Search" />
	</form>
	<hr />
	<h3>Results</h3>
	<?php
class Trim
{
protected $word;
function trimit( $word )
    {
        if ( empty($word) ) {
            return false;
        }

        $result = '';

        $word = strtolower($word);

        // Strip punctuation, etc. Keep ' and . for URLs and contractions.
        if ( substr($word, -2) == "'s" ) {
            $word = substr($word, 0, -2);
        }
        $word = preg_replace("/[^a-z0-9'.-]/", '', $word);

        $first = '';
        if ( strpos($word, '-') !== false ) {
            $first = substr($word, 0, strrpos($word, '-') + 1); 
            $word = substr($word, strrpos($word, '-') + 1);
        }
        if ( strlen($word) > 2 ) {
            $word = $this->plural_to_singular($word);
        }

        $result = $first . $word;

        return $result;
    }

    function plural_to_singular( $word )
    {

		if ( substr($word, -1) == 's' ) {
            if ( substr($word, -4) == 'sses' ) {
                $word = substr($word, 0, -2);
            } elseif ( substr($word, -3) == 'ies' ) {
                $word = substr($word, 0, -2);
            } elseif ( substr($word, -2, 1) != 's' ) {
                $word = substr($word, 0, -1);
            }
        }

        if ( substr($word, -3) == 'eed' ) {
			if ($this->count_vc(substr($word, 0, -3)) > 0 ) {
	            // Convert '-eed' to '-ee'
	            $word = substr($word, 0, -1);
			}
        } else {
            if ( preg_match('/([aeiou]|[^aeiou]y).*(ed|ing)$/', $word) ) {
                // Strip '-ed' or '-ing'
                if ( substr($word, -2) == 'ed' ) {
                    $word = substr($word, 0, -2);
                } else {
                    $word = substr($word, 0, -3);
                }
                if ( substr($word, -2) == 'at' || substr($word, -2) == 'bl' ||
                     substr($word, -2) == 'iz' ) {
                    $word .= 'e';
                } else {
                    $last_char = substr($word, -1, 1);
                    $next_to_last = substr($word, -2, 1);
                    if ( $this->is_consonant($word, -1) &&
                         $last_char == $next_to_last &&
                         $last_char != 'l' && $last_char != 's' && $last_char != 'z' ) {
                        $word = substr($word, 0, -1);
                    } else {
                        if ( $this->count_vc($word) == 1 && $this->_o($word) ) {
                            $word .= 'e';
                        }
                    }
                }
            }
        }
        if ( preg_match('/([aeiou]|[^aeiou]y).*y$/', $word) ) { // vowel in root
            $word = substr($word, 0, -1) . 'i';
        }
        return $word;
    }

    function is_consonant( $word, $pos )
    {
        
        if ( abs($pos) > strlen($word) ) {
            if ( $pos < 0 ) {
                $pos = 0;
            } else {
                $pos = -1;
            }
        }
        $char = substr($word, $pos, 1);
        switch ( $char ) {
            case 'a':
            case 'e':
            case 'i':
            case 'o':
            case 'u':
                return false;
            case 'y':
                if ( $pos == 0 || strlen($word) == -$pos ) {
                    // Check second letter of word.
                    // If word starts with "yy", return true.
                    if ( substr($word, 1, 1) == 'y' ) {
                        return true;
                    }
                    return !($this->is_consonant($word, 1));
                } else {
                    return !($this->is_consonant($word, $pos - 1));
                }
            default:
                return true;
        }
    }


    function count_vc( $word )
    {
        $m = 0;
        $length = strlen($word);
        $prev_c = false;
        for ( $i = 0; $i < $length; $i++ ) {
            $is_c = $this->is_consonant($word, $i);
            if ( $is_c ) {
                if ( $m > 0 && !$prev_c ) {
                    $m += 0.5;
                }
            } else {
                if ( $prev_c || $m == 0 ) {
                    $m += 0.5;
                }
            }
            $prev_c = $is_c;
        }
        $m = floor($m);
        return $m;
    }


    function _o( $word )
    {
        if ( strlen($word) >= 3 ) {
            if ( $this->is_consonant($word, -1) && !$this->is_consonant($word, -2) &&
                 $this->is_consonant($word, -3) ) {
		        $last_char = substr($word, -1);
		        if ( $last_char == 'w' || $last_char == 'x' || $last_char == 'y' ) {
		            return false;
		        }
                return true;
            }
        }
        return false;
    }

    function _replace( &$word, $suffix, $replace, $m = 0 )
    {
        $sl = strlen($suffix);
        if ( substr($word, -$sl) == $suffix ) {
            $short = substr_replace($word, '', -$sl);
            if ( $this->count_vc($short) > $m ) {
                $word = $short . $replace;
            }
            return true;
        }
        return false;
    }
}
if($_GET['inputbox']) {
	 #SEARCH ITEMS
	# ===============
	
	// read values from POST
	
	$word = $_GET['inputbox'];
	

	if ($word != "") {
		$temp = new Trim;
		$final = $temp->trimit( $word );
		}
	else {
		
		echo "<font color='red'>You must enter a word for the search</font>";
		
	}
}

		$database = "ceglugor_search";
		
		$searchqry = $final;
		
		$con = mysql_connect("localhost", "ceglugor", "hA4HaUEFeO") or die("Cannot connect to database:".mysql_error());
		$db = mysql_select_db($database, $con) or die("Database not found:".mysql_error());
		
		$tobequeried = "SELECT * FROM `completed` WHERE `KEYWORDS` LIKE '%".$searchqry."%'";
		
		$result = mysql_query($tobequeried, $con) or die("Query execution failed:".mysql_error());
		
		echo "<ul>";
		
		while($row = mysql_fetch_array($result))
		{
			echo "<li><a href=\"".$row['URL']."\">".$row['URL']."</a></li>";
		}
		
		echo "</ul>";
		
		mysql_close($con);
	?><div class="footer">
<center><!--beginfooter-->mobile version by ICW<!--endfooter--></div><!--beginadfooter--></center>
   
</body></html>