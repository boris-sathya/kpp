<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>Stock Market</title> 
</head> 
<body>
<div style="width: 220px;"><div id="xcolor1_1" style="border:1px solid #000;background-color:#94abf0;padding: 0px 0px;margin: 0px 0px;align:center;overflow:hidden;"><div id="xcolor1_2" style="font-size:12px;line-height:16px;font-family: arial; font-weight:bold;background:#94abf0;padding: 3px 1px;text-align:center;"><a href="http://www.stockindex500.com/" alt="Global Stock Index" title="Global Stock Index" id="stockindex500_link" style="color:#000000;font-size:14px;text-decoration:none;line-height:16px;font-family: arial;" >Global Stock Index</a></div><script src="http://www.stockindex500.com/z.php?z=stockindex&jc=g&c=94abf0"></script></div><div style="text-align:center;"><a href="http://www.stockindex500.com/" style="font-size:12px;"></a></div></div>  
 
</body> 
</html> 