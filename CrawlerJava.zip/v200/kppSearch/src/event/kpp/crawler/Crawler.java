package event.kpp.crawler;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Connection;
import java.sql.Statement;
import java.text.SimpleDateFormat;


public class Crawler {
	
	/**
	 * This is the main program where the crawler starts executing.
	 * This implements the algorithm which is shown in the Algoritm.txt file.
	 * 
	 */
	
	public static void checkRobots(URL toBeChecked, URLManipulations urlManip) throws Exception
	{
		/**
		 * Every site can have a robots.txt file.
		 * If this file has a ".Disallow" line in it then you are not allowed to crawl that site.
		 * You can take a look at this site for further details
		 * 
		 * http://www.robotstxt.org/robotstxt.html
		 * 
		 * 
		 */
		InputStream is = null;
		//DataInputStream dis;
		String s;
		Statement stmt = null;
		Connection con = null;
		
		BufferedReader dis = null;
		
		//try
		//{
			URL actualValue = new URL("http://"+toBeChecked.getHost()+"/robots.txt");
			is = actualValue.openStream();
			
			//dis = new DataInputStream(new BufferedInputStream(is));
			
			dis = new BufferedReader(new InputStreamReader(is));
			
			while((s = dis.readLine())!=null)
			{
				if(s.contains("Disallow"))
				{
					/**
					 * The URLs which are disallowed are inserted into the database here.
					 * Check the syntax of the robots.txt file to understand the below statement.
					 */
					String toBeInserted = "http://"+toBeChecked.getHost().trim()+s.substring(s.indexOf(":")+1).trim();
					
					/**
					 * This code is used to create a connection with the Database.
					 * Check DbAccess.java for more details.
					 */
					URL val = new URL(toBeInserted);
					boolean canAccess = urlManip.checkAccessRights(val);
						

					if(canAccess == true)
	                {
						DbAccess getDbAccess = new DbAccess();
						
						con = getDbAccess.getConnection();
						
						stmt = con.createStatement();
						
						/**
						 * It just inserts the URLs. I've not checked for any duplicate entries in the DISALLOWED table.
						 * May be you can do it and get your points ticking :)
						 */
						
						String qry = "insert into DISALLOWED values('"+toBeInserted.trim()+"',CURRENT_TIMESTAMP)";
						
						int rs = stmt.executeUpdate(qry);
						
						if(rs<0)
						{
							System.out.println("Insert was unsuccessful");
							System.exit(1);
						}
					   
					    stmt.close();
					    con.close();
	                }
                    else
                    {
                        System.out.println("Already in table");
                    }
				}
			}
		//}
		//catch(Exception e)
		//{
		//	e.printStackTrace();
		//	return;
		//}
		//finally
		//{
			
		//}
	}
	
	public static void main(String[] args)
	{

		

		URL theMainURL = null;
        URLConnection connection;
		//User Defined Classes
		URLManipulations urlManip = null;
		StringManipulations strManip = null;
		CrawlPage crawlPage = null;

		//In-built classes
		InputStream is = null;
		DataInputStream dis;
	    String filename,s;
	    FileWriter fw = null;
	    String ObtainedKeywords = null;
        String ObtainedCountry = null;
	    String validatedKeywords = null;

	    String fileType = null;
        String ObtainedTitle=null;
        String data=null;
//	    boolean checkDownload = false;

		try
		{
			// Creating instances
			urlManip = new URLManipulations();
			strManip = new StringManipulations();
			crawlPage = new CrawlPage();

			//Just a label for the while loop to use in continue or break statements
			theMainWhileLoop:
			while((theMainURL = urlManip.readFirstURL())!=null)
			{
				/*checkDownload = urlManip.canDownload(theMainURL);
                if(checkDownload == false)
                {
                	urlManip.deleteURL(theMainURL);
                	continue theMainWhileLoop;
                }*/
				int m = 0;
				System.out.println("Scanning..."+theMainURL.toString());

			/*	try{
				
				checkRobots(theMainURL, urlManip);
				}
				catch(Exception e)
				{
                    System.out.println("Robots are present");
					urlManip.deleteURL(theMainURL);
					continue theMainWhileLoop;
				}
*/
			
				boolean canAccess = urlManip.checkAccessRights(theMainURL);



				//If not I simply delete the URL from the WAITING table and go back to repeat the process
				if(canAccess == false)
				{
					urlManip.deleteURL(theMainURL);
					continue theMainWhileLoop;
				}
				else
				{
					
                   connection = theMainURL.openConnection();
					boolean isValidType = urlManip.checkFileType(connection);
					if(!isValidType)
					{

						urlManip.deleteURL(theMainURL);
						continue theMainWhileLoop;
					}
					try
					{
						
						is = theMainURL.openStream();
						dis = new DataInputStream(new BufferedInputStream(is));

						/**
						 * The file is downloaded the second time even if it was already cached.
						 * This is a probable wastage of space. Should not happen. :(
						 */

						String temp = theMainURL.toString();

						/**
						 * This takes the file type and adds it to the file name.
						 *
						 * The following issue is addressed :)
						 * -------
						 * But this is not 100%. Consider www.ceglug.org,
						 * It takes the data from the last dot (.)
						 * As a result ".org" is retrieved. Your file extension thus becomes something.org.
						 * This should not happen.
						 * Citing for improvements.
						 * -------
						 */

						fileType = temp.substring(temp.lastIndexOf('.'), temp.length());

						if(!(fileType.equals(".html")||fileType.equals(".php")||fileType.equals(".jsp")))
			            {
							fileType =".html";

							System.out.println("Changed");
			            }


						filename = urlManip.lastmodified(theMainURL.toString());

						//filename += (new SimpleDateFormat("ddMMyyhhmmssSSS")).format( new java.util.Date());

						m=(int)(Math.random()*10000000);

						File fi = new File("cache/"+filename+"k" +m+fileType);


						fw = new FileWriter(fi, true);

						while((s = dis.readLine())!=null)
						{
							fw.write(s+"\n");
						}

						is.close();

						fw.close();
					}
					catch(FileNotFoundException e)
					{
						System.out.println("Can reach here "+e.toString());
						urlManip.deleteURL(theMainURL);
						continue theMainWhileLoop;
					}
				}

				/**
				 * From the HTML file downloaded I take in all the keywords.
				 */
				ObtainedKeywords = crawlPage.getKeywords(theMainURL);
                  ObtainedTitle = crawlPage.getTitle(theMainURL);
                
				//I validate them. Check StringManipulations class for more details.
				validatedKeywords = strManip.validateString(ObtainedKeywords);
                ObtainedCountry=crawlPage.getcountry(theMainURL);
                System.out.print(ObtainedCountry);
                data=crawlPage.getData(theMainURL);
                System.out.println(data);
                //Inserting the cached Keywords into the COMPLETED table.
				int test = urlManip.insertURLKeywords(theMainURL, filename+"k"+m+fileType, validatedKeywords,ObtainedTitle,ObtainedCountry,data);
				if(test<0)
				{
                    
					//If the Page was already cached then this shows an error.
					//So just delete the URL from WAITING table and go back to the while loop.
					System.out.println("The Page "+theMainURL.toString()+ " was already cached");
					urlManip.deleteURL(theMainURL);
					continue theMainWhileLoop;
				}

				//Once cached delete it from the WAITING table
				urlManip.deleteURL(theMainURL);

				//Get all the links from the page and add it to the WAITING table.
				//You need to make the links valid. Check the StringManipulations class for more details.
				Object[] theLinks = crawlPage.getLinks(theMainURL);
				String theObtainedLink = null;
				for(int k=0; k<theLinks.length; k++)
				{
					theObtainedLink = strManip.BuildValidLinkFromString(theLinks[k], theMainURL);

					if(theObtainedLink != null)
					{
						urlManip.AddURLToWaitingQueue(theObtainedLink,theLinks.length,theMainURL);
					}
				}

				//Go over and repeat the functions repeatedly :)
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}


}
