package event.kpp.crawler;

class BlankRemover {

    public BlankRemover () {}

    /* remove leading whitespace */
    public  String ltrim(String source) {
        return source.replaceAll("^\\s+", "");
    }

    /* remove trailing whitespace */
    public String rtrim(String source) {
        return source.replaceAll("\\s+$", "");
    }

    /* replace multiple whitespaces between words with single blank */
    public  String itrim(String source) {
        return source.replaceAll("\\b\\s{2,}\\b", "");
    }

    /* remove all superfluous whitespaces in source string */
    public String trim(String source) {
        return itrim(ltrim(rtrim(source)));
    }

    public String lrtrim(String source){
        return ltrim(rtrim(source));
    }
    }