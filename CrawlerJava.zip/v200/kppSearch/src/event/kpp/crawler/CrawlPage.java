package event.kpp.crawler;

import org.htmlcleaner.HtmlCleaner;
import org.htmlcleaner.TagNode;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CrawlPage 
{
	
	/**
	 * All the functions pertaining to crawling a page and obtaining contents from it are implemented in this class.
	 * This is fairly simple class. Here I've used the HTMLCleaner Library to make the crawling work easier.
	 * 
	 */
	
	public String getKeywords(URL theMainURL)
	{
		/**
		 * Crawl the input URL and obtain the keywords from it.
		 * That is, goto the meta tag and get the keywords.
		 * <meta name='keywords' content='mysitekeywords,test, test' />
		 * I'm taking the value of the CONTENT field from this.
		 */
		
		//I've created an Object for HTMLCleaner
		HtmlCleaner cl = null;
		
		/**
		 * The HTMLCleaner converts the given HTML file into an XML file and it adds the missing tags if any.
		 * The result is taken in a TagNode.
		 */
		TagNode cleanedURL = null;
		String KeyWordsToBeInserted = null;
		
		try{
		
			cl = new HtmlCleaner();
			
			cleanedURL = cl.clean(theMainURL);
			
			/**
			 * I'm querying the created XML here using an Xpath expression.
			 * XPath is simple. Its similar to SQL. Just take a look at the syntaxes here : 
			 * http://www.w3schools.com/XPath/xpath_syntax.asp
			 * 
			 * The data function is used to obtain the data from the tag.
			 * Take a look at the site below to see various the XPath expressions HTMLCleaner supports.
			 * http://htmlcleaner.sourceforge.net/doc/org/htmlcleaner/TagNode.html#evaluateXPath(java.lang.String)
			 */
			
			Object[] theKeywords = cleanedURL.evaluateXPath("data(//meta[@name = 'keywords']/@content)");
			
			for(int i=0;i<theKeywords.length; i++)
			{
				KeyWordsToBeInserted += theKeywords[i].toString();
			}
			
			/**
			 * I'm concatenating all the keywords into a single string for database storage purposes.
			 */
			if(KeyWordsToBeInserted == null || KeyWordsToBeInserted.equals(""))
				KeyWordsToBeInserted = theMainURL.getHost();
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return KeyWordsToBeInserted;
	}
	
	public Object[] getLinks(URL theMainURL)
	{
		/**
		 * This function retrieves the various links in the page.
		 * That is the various <a href... > tags.
		 * The same HTMLCleaner login mentioned above is used.
		 */
		HtmlCleaner cl = null;
		TagNode cleanedURL = null;
		Object[] theLinks = null;
		
		try{
		
			cl = new HtmlCleaner();
			
			cleanedURL = cl.clean(theMainURL);
			
			theLinks = cleanedURL.evaluateXPath("data(//a[@href]/@href)");
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return theLinks;
	}

    public  String getcountry(URL url)
    {
       String u=null;
       long [] a=new long [4];
       Statement stmt = null;
       Connection con = null;
       String str;
       try
           {
          str=url.toString();
            String[] splitted = str.split("://");
            System.out.println(splitted[1]);
            String str2=splitted[1];
            String[] split2=str2.split("/");
            System.out.println(split2[0]);
           InetAddress thisIp =InetAddress.getByName(split2[0]);
           //System.out.print(splitted[1]);
           System.out.println("IP:"+thisIp.getHostAddress());
           String e=thisIp.getHostAddress().toString();
           System.out.println(e);

           String[] tokens = e.split("\\.");

           for(int i=0;i<4;i++)
           	a[i]=Integer.parseInt(tokens[i]);

               long res=a[0]*256*256*256+a[1]*256*256+a[2]*256+a[3];
//System.out.print(res);
               DbAccess getDbAccess = new DbAccess();

               con = getDbAccess.getConnection();

               stmt = con.createStatement();

               String qry = "select COUNTRY from ip_to_country where  IP_FROM <= '"+res+"'and IP_TO >= '"+res+"'";
                  System.out.println(qry);
               ResultSet rs = stmt.executeQuery(qry);
            rs.last();

           int rowcount=rs.getRow();
            if(rowcount==0)
                u="unknown";
            else
               u = rs.getString(1);

       System.out.println(u);

           }
   catch(Exception e)
           {
           e.printStackTrace();
           }
      return u;
      }

    public String getData (URL url)throws IOException
    {
 				BlankRemover bw=new BlankRemover();
               String sourceLine;
               String content = "";

               // The URL address of the page to open.
               URL address = url;

               // Open the address and create a BufferedReader with the source code.
               InputStreamReader pageInput = new InputStreamReader(address.openStream());
               BufferedReader source = new BufferedReader(pageInput);

               // Append each new HTML line into one string. Add a tab character.
               while ((sourceLine = source.readLine()) != null)
                       content += sourceLine + "\t";

               // Remove style tags & inclusive content
               Pattern style = Pattern.compile("<style.*?>.*?</style>");
               Matcher mstyle = style.matcher(content);
               while (mstyle.find()) content = mstyle.replaceAll("");
                Pattern style1 = Pattern.compile("<STYLE.*?>.*?</STYLE>");
               Matcher mstyle1 = style1.matcher(content);
               while (mstyle1.find()) content = mstyle1.replaceAll("");

                Pattern style2 = Pattern.compile("<a.*?>.*?</a>");
               Matcher mstyle2 = style2.matcher(content);
               while (mstyle2.find()) content = mstyle2.replaceAll("");

                 Pattern style3 = Pattern.compile("<title.*?>.*?</title>");
               Matcher mstyle3 = style3.matcher(content);
               while (mstyle3.find()) content = mstyle3.replaceAll("");


               // Remove script tags & inclusive content
               Pattern script = Pattern.compile("<script.*?>.*?</script>");
               Matcher mscript = script.matcher(content);
               while (mscript.find()) content = mscript.replaceAll("");

               // Remove primary HTML tags
               Pattern tag = Pattern.compile("<.*?>");
               Matcher mtag = tag.matcher(content);
               while (mtag.find()) content = mtag.replaceAll("");

               // Remove comment tags & inclusive content
               Pattern comment = Pattern.compile("<!--.*?-->");
               Matcher mcomment = comment.matcher(content);
               while (mcomment.find()) content = mcomment.replaceAll("");

               // Remove special characters, such as &nbsp;
               Pattern sChar = Pattern.compile("&.*?;");
               Matcher msChar = sChar.matcher(content);
               while (msChar.find()) content = msChar.replaceAll("");

              //  Remove the tab characters. Replace with new line characters.
              Pattern nLineChar = Pattern.compile("\t+");
              Matcher mnLine = nLineChar.matcher(content);
               while (mnLine.find()) content = mnLine.replaceAll("");

               // Print the clean content & close the Readers
             content=bw.ltrim(content);
              	content=bw.rtrim(content);
              	content=bw.itrim(content);
              	content=bw.trim(content);
              //	content=content.replaceAll("\\S+"," ");
               //System.out.println(content);
               content= content.replaceAll("'","\\\\'");

               pageInput.close();
               source.close();
               return content;
       }

    public String getTitle(URL theMainURL)
	{
  HtmlCleaner cl = null;

		TagNode cleanedURL = null;
		String TitleToBeInserted = null;
		try{

			cl = new HtmlCleaner();

			cleanedURL = cl.clean(theMainURL);

		    Object[] theTitle = cleanedURL.evaluateXPath("data(//title)");

				TitleToBeInserted = theTitle[0].toString();


		    if(TitleToBeInserted == null || TitleToBeInserted.equals(""))
				TitleToBeInserted = theMainURL.getHost();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
         TitleToBeInserted= TitleToBeInserted.replaceAll("'","\\\\'");
        return TitleToBeInserted;
		

	}
}
