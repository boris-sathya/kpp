package event.kpp.crawler;

import java.net.URL;
import java.net.URLConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class URLManipulations {
	/**
	 * Any manipulations done with the URL are added to this class.
	 * @return
	 */
	
	public URL readFirstURL()
	{
		/**
		 * This function is used to read the top URL from the WAITING table.
		 * The WAITING table is the one which has the list of URLs which need to be cached.
		 */
		URL u = null;
		Statement stmt = null;
		Connection con = null;
		try
		{
			DbAccess getDbAccess = new DbAccess();
			
			con = getDbAccess.getConnection();
			
			stmt = con.createStatement();
			
			/**
			 * The following query chooses the 1st URL from the WAITING table.
			 */
			
			String qry = "select URL from WAITING limit 1";
			
			ResultSet rs = stmt.executeQuery(qry);
			
			rs.next();
			u = new URL(rs.getString(1));
		}
		catch (Exception e)
		{
			System.out.println("The exception was 1 "+e.toString());
			u=null;
		}
		finally
		{
			try 
			{
				stmt.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				//Ignored
			}
		}
		
		return u;
	}
	
	public int deleteURL(URL u)
	{
		/**
		 * This function deletes the the given URL from the WAITING table.
		 * This is generally done when the URL has been crawled.
		 */
		Statement stmt = null;
		int k = 0;
		Connection con = null;
		try
		{
			DbAccess getDbAccess = new DbAccess();
			
			con = getDbAccess.getConnection();
			
			stmt = con.createStatement();
			
			/**
			 * Note: The top URL has not been deleted but all entries of the URL have been deleted.
			 * This is because, once the URL is crawled it need not be crawled again.
			 */
			
			String qry = "delete from WAITING where URL = '"+u.toString()+"'";
			
			k = stmt.executeUpdate(qry);
			
		}
		catch (Exception e)
		{
			System.out.println("The exception was here "+e.toString());
		}
		finally
		{
			try 
			{
				stmt.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				//Ignored
			}
		}
		
		return k;
	}
	
	public boolean checkAccessRights(URL requestURL)
	{
		
		/**
		 * The DISALLOWED table contains the list of entries which cannot be crawled.
		 * If the URL is present in that list then it should not be crawled.
		 * This condition is checked here.
		 */
		
		Statement stmt = null;
		ResultSet rsn = null;
		boolean result = true;
		Connection con = null;
		
		try
		{
			DbAccess getDbAccess = new DbAccess();
			
			con = getDbAccess.getConnection();
			
			stmt = con.createStatement();
			
			String qry = "select url from DISALLOWED where url like '%"+requestURL.getHost() +"%'";
			
			rsn = stmt.executeQuery(qry);
			
			while(rsn.next())
			{
				if(requestURL.equals(rsn.getString(1)))
				{
					result = false;
					break;
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				stmt.close();
				con.close();
			} catch (SQLException e) {
				// Ignored
			}
		}
		
		return result;
	}
	
	public boolean checkFileType(URLConnection con)
	{
		
		

		if(con.getContentType().toString().contains("text/html"))
        {
           
            return true;
        }
        else
            return false;

		
	}
	
	public int insertURLKeywords(URL theMainURL, String filepath, String keywords,String title,String Country,String data)
	{
		/**
		 * Once crawled you will want to insert the URL and its corresponding KEYWORDS into the table.
		 * The COMPLETED table holds these values.
		 * This insertion is done here.
		 */
		Statement kywrdsStmt = null;
		Connection con = null;
		int t =0;
        double count=0.15;
        double length=0;
		try
		{
			DbAccess getDbAccess = new DbAccess();

			con = getDbAccess.getConnection();

            String[] arr = data.split(" ");
            length = arr.length;
            count = count+Math.log(length)/9;
			String kywdqry = "insert into COMPLETED values('"+theMainURL.toString()+"','"+filepath+"','"+keywords.trim()+"',CURRENT_TIMESTAMP,0,'"+title.trim()+"','"+Country.trim()+"','"+data.trim()+"',"+count+","+length+")";
            
			kywrdsStmt = con.createStatement();

			t = kywrdsStmt.executeUpdate(kywdqry);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			t = -1;
		}
		finally
		{
			try {
				kywrdsStmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return t;
	}

	
	public int AddURLToWaitingQueue(String theLinkObtained,int no,URL theMainUrl)
	{
		/**
		 * If you want to add a new URL to the WAITING table then this function can be used.
		 */
		URL temp = null;
		Statement stmt1 = null;
		Connection con1 = null;
        		Statement stmt2 = null;
		Connection con2 = null;
        	Statement stmt3 = null;
		Connection con3 = null;

        int res = 0;
        ResultSet res2=null;
        int res1=0;
        double u=0;
        double count=0;
		try{

			DbAccess getDbAccess = new DbAccess();

			con1 = getDbAccess.getConnection();
            con2= getDbAccess.getConnection();
                        con3= getDbAccess.getConnection();
			temp = new URL(theLinkObtained);
			String InsertQuery = "insert into WAITING values('"+temp.toString()+"', CURRENT_TIMESTAMP)";
		    String qry="select rank from completed where URL like '"+theMainUrl.toString()+"'";
            stmt1 = con1.createStatement();
            stmt2= con2.createStatement();
            stmt3= con3.createStatement();
            res2 = stmt2.executeQuery(qry);
            
            //System.out.println(Upd);
            res2.next();
			u = Double.parseDouble(res2.getString(1));
            count = 0.85*u/no;
			res = stmt3.executeUpdate(InsertQuery);
            String Upd="update completed set RANK=RANK+ "+count+" where URL like '"+temp.toString()+"'";
            res1 = stmt1.executeUpdate(Upd);
        }
		catch(Exception e)
		{
			e.printStackTrace();
			res = -1;
		}
		finally
		{
			try{
				stmt1.close();
				con1.close();
                stmt2.close();
				con2.close();
			stmt3.close();
				con3.close();

			}
			catch(Exception e)
			{
				//Ignored
			}
		}

		return res;
	}
	
	public String lastmodified(String mainurl)
    {
        try{
            URL a = new URL(mainurl);

            URLConnection con = a.openConnection();

            con.connect();

            long b=con.getLastModified();
            String c=Long.toString(b);
            return c;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return "a";
        }
    }
	
	public boolean canDownload(URL requestURL)
	{
		Statement stmt = null;
		ResultSet rsn = null;
        int rso=0;
		boolean result=true;
		Connection con = null;

		try
		{
			DbAccess getDbAccess = new DbAccess();

			con = getDbAccess.getConnection();

			stmt = con.createStatement();
            String e="a";
			String qry = "select PATHINCACHE,url from COMPLETED where url like '"+requestURL +"'";
            System.out.println(qry);
			rsn = stmt.executeQuery(qry);

            while(rsn.next())
            {
                e=rsn.getString(1);
                //System.out.println(e);
            }
            rsn.last();

            int rowcount=rsn.getRow();
            if(rowcount==0)
            {
                result=true;
            }
            else
            {
                String d=lastmodified(requestURL.toString());
                if(!d.equalsIgnoreCase("0"))
                {
	                String f=e.substring(0, e.indexOf("k"));
	                if(d.compareTo(f)>0)
	                {
	                    qry="delete from completed where url like '"+requestURL+"'";
	                    System.out.println(qry);
	                    rso = stmt.executeUpdate(qry);
	                    result=true;
	                }
	                else
	                	result=false;
                }
                else
                {
                	qry="delete from completed where url like '"+requestURL+"'";
                    System.out.println(qry);
                    rso = stmt.executeUpdate(qry);
                    result=true;
                }
            }
              
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				stmt.close();
				con.close();
			} catch (SQLException e) {
				// Ignored
			}
		}

		return result;
	}


}
