package event.kpp.crawler;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbAccess {
	
	/**
	 * Connections to the database originate here.
	 * @return
	 */
	
	public Connection getConnection()
	{
		/**
		 * Connection to the database is done in this class and returned from here.
		 * You can use only this class for connecting to database.
		 * 
		 * Reason:
		 * When deployment the password of the MySQL server may vary from your local server's password.
		 * In such cases you need not go around all the classes changing the passwords.
		 * Instead this function can be changed and can be used as a single point of access :)
		 * This just improves code portability.
		 * 
		 * You can even change the driver when deploying on a different database.
		 */
		Connection con = null;
		try
		{
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			String url = "jdbc:mysql://localhost/search";
			con = DriverManager.getConnection(url, "root", "");			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return con;
	}

}
