package event.kpp.crawler;

import java.net.URL;

public class StringManipulations 
{
	/**
	 * Manipulating the Strings to our need are done here.
	 * Any kind of functions pertaining to String Manipulations are put here.
	 */
	public String validateString(String theString)
	{
		/**
		 * The KEYWORDS which you insert into the table should not contain special characters like single quotes etc.
		 * These manipulations are done in this function.
		 * 
		 *  Reason:
		 *  when you insert into your table you statement will be something like
		 *  insert into tablename values ('string to be inserted');
		 *  
		 *  Now try inserting a single quote in the "string to be inserted"
		 *  insert into tablename values ('string to be 'inserted');
		 *  
		 *  You can run into an SQL error,
		 *  because according to the SQL compiler your String has ended with the word "be" and not with the word "inserted".
		 *  
		 *  Also take a look at articles relating to SQL Injection. This can give you more ideas on how to improve this function.
		 */
		StringBuffer inp = new StringBuffer(theString);
		for(int j=0; j<inp.length(); j++)
		{
			if(inp.charAt(j) == '\'')
			{
				inp.deleteCharAt(j);
			}
		}
		
		return inp.toString();
	}
	
	public String BuildValidLinkFromString(Object theLink, URL theMainURL)
	{
		/**
		 * When you build a website its usual to give relative addressing. For example,
		 * you might use
		 * 
		 * <a href="index.php">Goto Home</a>
		 * 
		 * Here the index.php is present in the same page as that of the current page.
		 * When crawling you need to add the site's URL to this index.php
		 * 
		 * That is, for example your crawled result should be,
		 * http://www.ubuntu.com/index.php
		 * 
		 * This manipulation is done here.
		 *  
		 */
		StringBuffer br = new StringBuffer(theLink.toString());
		String result = null;
		
		if(br.length() == 0)
			return result;
		
		if(br.charAt(0) == '/')
		{
			/**
			 * If the link starts with /
			 * That is, if its /index.php or /contents/main.php then you just need to append the site name.
			 * That is you should make it, http://www.example.com/index.php
			 */
			br.deleteCharAt(0);
			result=theMainURL.toString()+br.toString();
		}
		else
		{
			if(br.charAt(0) == '#')
			{
				/**
				 * Links which start with # are only internal links which can be ignored.
				 */
			}
			else
			{
				if(br.charAt(0) == 'h')
				{
					/**
					 * The first character being 'h' implies that it is a 'http' link.
					 * You can improve this function here.
					 */
					result=br.toString();
				}
			}
		}
		
		return result;
	}
	
}
